//
//  ViewController.swift
//  MQTT Demo
//
//  Created by Ghencian Timotei on 30/03/2021.
//

import UIKit
import CocoaMQTT
import CoreMotion
import WebKit

class ViewController: UIViewController {
    
    
    @IBOutlet var wv: WKWebView!
    
    
    var pitch = 0
    @IBOutlet weak var xAcclel: UILabel!

    let motion = CMMotionManager()
    
    let mqttClient = CocoaMQTT(clientID: "iOS Device", host: "192.168.0.104", port: 1883)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        wv.load(URLRequest(url: URL(string: "http://192.168.0.102:8081")!))
        wv.sizeToFit()
        
        wv.isMultipleTouchEnabled = false
        myDeviceMotion()
        
//        wv.allowsBackForwardNavigationGestures = false
        
    }

    @IBAction func forwardMove(_ sender: UIButton) {
        mqttClient.publish("rpi/motor", withString: "\(100)")
    }
    @IBAction func stop(_ sender: Any) {
        mqttClient.publish("rpi/motor", withString: "\(50)")
    }
    @IBAction func backwardMode(_ sender: UIButton) {
        mqttClient.publish("rpi/motor", withString: "\(0)")
    }
    @IBAction func connectButton(_ sender: UIButton) {
        mqttClient.connect()

    }
    @IBAction func disconnectButton(_ sender: UIButton) {
        mqttClient.disconnect()
    }
    
    func myDeviceMotion () {
        motion.deviceMotionUpdateInterval = 0.05
        motion.startDeviceMotionUpdates(to: OperationQueue.current!) { (data, error) in
            if let trueData = data {
                self.view.reloadInputViews()
                self.pitch = Int.init(trueData.attitude.pitch * 100) > 100 ? 100 : (Int.init(trueData.attitude.pitch * 100) < -100 ? -100 : Int.init(trueData.attitude.pitch * 100))
                self.xAcclel.text = "\(self.pitch)"
                self.mqttClient.publish("rpi/gpioFloat", withString: "\(Int(self.pitch))")
            }
        }
            
        }
    }


extension Double {
    func rounded(toPlaces places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded()
    }
}

