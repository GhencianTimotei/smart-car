
#Import essential modules
import paho.mqtt.client as mqtt
from gpiozero import Motor

motor = Motor(2, 3)
 
def gpioSetup():
    
    #Set pin numbering to Broadcom scheme
    gpio.setmode(gpio.BCM)
    
    #Set GPIO21 (pin 40) as an output pin
    gpio.setup(21, gpio.OUT)
 
def connectionStatus(client, userdata, flags, rc):
    #Subscribe client to a topic
    mqttClient.subscribe("rpi/motor")
    
def messageDecoder(client, userdata, msg):
    #Decode message received from topic
    message = msg.payload.decode(encoding='UTF-8')
    #Set GPIO pin 40 HIGH or LOW
    #f message == "on":
    #    ledOn = True
    #    print("LED is ON!")
    #elif message == "off":
    #    ledOn = False
    #    print("LED is LOW!")
    #else:
    #    ledPWM = int(message)
    #
    #if ledOn:
    #    p.ChangeDutyCycle(ledPWM)
    #else:
    #    p.ChangeDutyCycle(0)
    motor.value=((float(message)-50)/100)*2
    print(((float(message)-50)/100)*2)
        
#Set up RPI GPIO pins
#gpioSetup()
#p = gpio.PWM(21, 1000)
#p.start(0)
#Set client name
clientName = "RPI3B_motor"

#Set MQTT server address
serverAddress = "192.168.0.104"

#Instantiate Eclipse Paho as mqttClient
mqttClient = mqtt.Client(clientName)

#Set calling functions to mqttClient
mqttClient.on_connect = connectionStatus
mqttClient.on_message = messageDecoder

#Connect client to Server
mqttClient.connect(serverAddress)

#Monitor client activity forever
mqttClient.loop_forever()
