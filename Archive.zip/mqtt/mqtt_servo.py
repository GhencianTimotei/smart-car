#!/usr/bin/env python
# -*- coding: utf-8 -*-

#Import essential modules
import paho.mqtt.client as mqtt
import RPi.GPIO as gpio
import pigpio

pi = pigpio.pi()
ledPWM = 0


def translate(value, leftMin, leftMax, rightMin, rightMax):
    # Figure out how 'wide' each range is
    leftSpan = leftMax - leftMin
    rightSpan = rightMax - rightMin

    # Convert the left range into a 0-1 range (float)
    valueScaled = float(value - leftMin) / float(leftSpan)

    # Convert the 0-1 range into a value in the right range.
    return rightMin + (valueScaled * rightSpan)

def gpioSetup():
    
    #Set pin numbering to Broadcom scheme
    gpio.setmode(gpio.BCM)
    
    #Set GPIO21 (pin 40) as an output pin
    gpio.setup(21, gpio.OUT)
    
    
def connectionStatus(client, userdata, flags, rc):
    #Subscribe client to a topic
    mqttClient.subscribe("rpi/gpioBool")
    mqttClient.subscribe("rpi/gpioFloat")
    
def messageDecoder(client, userdata, msg):
    global pi
    global ledPWM
    #Decode message received from topic
    message = msg.payload.decode(encoding='UTF-8')
    #Set GPIO pin 40 HIGH or LOW
    #f message == "on":
    #    ledOn = True
    #    print("LED is ON!")
    #elif message == "off":
    #    ledOn = False
    #    print("LED is LOW!")
    #else:
    #    ledPWM = int(message)
    #
    #if ledOn:
    #    p.ChangeDutyCycle(ledPWM)
    #else:
    #    p.ChangeDutyCycle(0)
    angle = translate(int(message), 100, -100, 655, 1240)
    print(message)
    pi.set_servo_pulsewidth(18, int(angle))
        
#Set up RPI GPIO pins
#gpioSetup()
#p = gpio.PWM(21, 1000)
#p.start(0)
#Set client name
clientName = "RPI3B_Servo"

#Set MQTT server address
serverAddress = "192.168.0.104"

#Instantiate Eclipse Paho as mqttClient
mqttClient = mqtt.Client(clientName)

#Set calling functions to mqttClient
mqttClient.on_connect = connectionStatus
mqttClient.on_message = messageDecoder

#Connect client to Server
mqttClient.connect(serverAddress)

#Monitor client activity forever
mqttClient.loop_forever()